(() => {
  const STORAGE_KEY = "manglam-public-site-data-v2";
  const starter = window.MANGLAM_DATA || {rates:{},products:[]};
  let data;
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    data = saved ? JSON.parse(saved) : structuredClone(starter);
  } catch (_) { data = JSON.parse(JSON.stringify(starter)); }
  data.rates = data.rates || {};
  data.products = Array.isArray(data.products) ? data.products : [];
  const save = () => localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  const format = value => value == null || value === "" ? "Call for rate" :
    "₹" + Number(value).toLocaleString("en-IN", {maximumFractionDigits:2});
  const rateCards = document.querySelectorAll(".rate-card");
  const rateKeys = ["gold24","gold22","gold20","gold18","silver"];
  const renderRates = () => {
    rateCards.forEach((card, i) => {
      const value = data.rates[rateKeys[i]];
      card.querySelector(".rate-value").textContent = format(value);
      card.querySelector(".rate-unit").textContent = value == null || value === "" ? "Please call to confirm" : "per gram";
      card.querySelector(".rate-ten").textContent = value == null || value === "" ? "" :
        (i === 4 ? "1kg: " : "10g: ") + format(Number(value) * (i === 4 ? 1000 : 10));
    });
  };
  const grid = document.getElementById("product-grid");
  const categories = document.getElementById("category-list");
  const products = data.products;
  let selectedCategory = "All Products";
  const escapeHTML = value => String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const whatsappLink = name => "https://wa.me/919891393189?text=" + encodeURIComponent("Hello Manglam Jewellers, I am interested in " + name + ". Please share details.");
  const renderProducts = () => {
    const filtered = selectedCategory === "All Products" ? products : products.filter(p => p.category === selectedCategory);
    if (!filtered.length) {
      grid.innerHTML = `<div class="empty-products"><span class="empty-icon">✧</span><h3>${products.length ? "No designs in this category yet" : "Our collection is being updated"}</h3><p>For designs and availability, contact Manglam Jewellers on WhatsApp.</p><a class="button button-outline" href="https://wa.me/919891393189?text=Hello%20Manglam%20Jewellers%2C%20please%20share%20your%20latest%20designs." target="_blank" rel="noopener">Ask for latest designs</a></div>`;
    } else {
      grid.innerHTML = filtered.map(p => `
        <article class="product-card">
          <img class="product-image" src="${p.image}" alt="${escapeHTML(p.name || "Manglam Jewellers product")}" loading="lazy">
          <div class="product-info"><h3>${escapeHTML(p.name || "Jewellery design")}</h3>
          <p>${escapeHTML(p.description || p.category || "")}</p>
          ${p.showPrice && p.price ? `<p>${escapeHTML(p.price)}</p>` : ""}
          <a class="product-enquire" target="_blank" rel="noopener" href="${whatsappLink(p.name || "this design")}">ENQUIRE ON WHATSAPP ↗</a></div>
        </article>`).join("");
    }
    renderManageList();
  };
  const manage = document.getElementById("manage-products");
  function renderManageList() {
    if (!manage) return;
    manage.innerHTML = products.map((p,i)=>`<div class="manage-product"><img src="${p.image}" alt=""><span>${escapeHTML(p.name)}</span><button type="button" data-remove="${i}">Remove</button></div>`).join("");
  }
  categories?.addEventListener("click", e => {
    const button = e.target.closest("button[data-category]");
    if (!button) return;
    categories.querySelectorAll("button").forEach(b => b.classList.remove("active"));
    button.classList.add("active");
    selectedCategory = button.dataset.category;
    renderProducts();
  });
  document.getElementById("rates-form")?.addEventListener("submit", e => {
    e.preventDefault();
    const form = e.currentTarget;
    for (const key of rateKeys) {
      const raw = form.elements[key].value.trim();
      data.rates[key] = raw === "" ? null : Number(raw);
    }
    save(); renderRates();
    document.getElementById("rates-save-status").textContent = "Rates saved in this browser.";
  });
  document.getElementById("product-form")?.addEventListener("submit", e => {
    e.preventDefault();
    const form = e.currentTarget;
    const file = form.elements.photo.files[0];
    if (!file) return;
    const status = document.getElementById("product-save-status");
    if (file.size > 2 * 1024 * 1024) {
      status.textContent = "Please choose an image under 2 MB.";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      products.unshift({
        name: form.elements.name.value.trim(),
        category: form.elements.category.value,
        image: reader.result,
        description: form.elements.description.value.trim(),
        price: form.elements.price.value.trim(),
        showPrice: form.elements.showPrice.checked
      });
      try {
        save(); renderProducts(); form.reset();
        status.textContent = "Product added and saved in this browser.";
      } catch (_) {
        products.shift();
        status.textContent = "Storage is full. Try a smaller photo.";
      }
    };
    reader.readAsDataURL(file);
  });
  manage?.addEventListener("click", e => {
    const button = e.target.closest("[data-remove]");
    if (!button) return;
    const index = Number(button.dataset.remove);
    products.splice(index,1);
    save(); renderProducts();
  });
  renderRates();
  renderProducts();

  const langButton = document.getElementById("language-toggle");
  let hindi = false;
  langButton?.addEventListener("click", () => {
    hindi = !hindi;
    document.querySelectorAll("[data-en][data-hi]").forEach(el => el.innerHTML = hindi ? el.dataset.hi : el.dataset.en);
    langButton.textContent = hindi ? "English" : "हिंदी";
  });
  document.getElementById("year").textContent = new Date().getFullYear();
})();

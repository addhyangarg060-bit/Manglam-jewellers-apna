/*
  EDIT THIS FILE TO UPDATE WEBSITE CONTENT.
  Enter rates as numbers (without ₹ or commas). Leave null to show "Call for rate".
  Example: gold24: 7250
*/
window.MANGLAM_DATA = {
  rates: {
    gold24: null,
    gold22: null,
    gold20: null,
    gold18: null,
    silver: null
  },
  products: [
    // Add products like this:
    // {
    //   name: "Silver Pendant",
    //   category: "Silver Jewellery",
    //   image: "assets/products/silver-pendant.jpg",
    //   description: "925 sterling silver",
    //   price: "Enquire for price",
    //   showPrice: true
    // }
  ]
};
